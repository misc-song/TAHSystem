<template>
    <div>系统状态</div>
</template>

<script>
    export default {
        name: "SysStatue",
    }
</script>

<style scoped>
</style>