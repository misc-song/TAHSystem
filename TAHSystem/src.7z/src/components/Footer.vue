<template>
    <div>
        ����footer
    </div>
</template>

<script>
    export default {
        name: "Footer"
        data() {
            return {}
        }

    }
</script>

<style scoped>
</style>