<template>
    <div>系统日志</div>
</template>

<script>
    export default {
        name: "SysLog",
    }
</script>

<style scoped>
</style>